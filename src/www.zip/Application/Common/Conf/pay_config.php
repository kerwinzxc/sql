<?php
return  array(
	'PAYMENU' => array(
		'alipay' => array (
	      'partner' => '2088221446826889',
	      'email' => 'service137box@163.com',
	      'key' => 'xbuubntv5j7vn5cazdpq3vby5et5md43',
	    ),
	    'weixin' => array (
	      'partner' => '2088021773xxx',
	      'email' => 'x',
	      'key' => 'clrsuvrbsxx',
	    ),
	),
);